//
//  presentViewController.h
//  presentAndDismissController
//
//  Created by MAC on 5/10/15.
//  Copyright (c) 2015 leuducquy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface presentViewController : UIViewController

@end
